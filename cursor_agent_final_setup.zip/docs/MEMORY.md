# Project Memory

Use this file as the project working memory.

## Project Summary

- Goal:
- Main users:
- Current status:

## Tech Stack

- Frontend:
- Backend:
- Database:
- Authentication:
- Deployment:

## Important Decisions

| Date | Decision | Reason | Impact |
|---|---|---|---|

## Current Project State

### Main Data Flow

### Auth Flow

### Important Folders

### Known Risks

## Error Log and Lessons Learned

| Date | Issue | Root Cause | Fix | Prevention |
|---|---|---|---|---|

## User Preferences

- Prefer TypeScript.
- Prefer clean modular architecture.
- Prefer safe planning before large edits.
- Prefer PowerShell commands on Windows.

## Recent Activity

| Date | Activity | Notes |
|---|---|---|
